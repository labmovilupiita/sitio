-- Adminer 3.6.3 MySQL dump

SET NAMES utf8;
SET foreign_key_checks = 0;
SET time_zone = 'SYSTEM';
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

USE `XPTELE`;

DROP TABLE IF EXISTS `asistencia`;
CREATE TABLE `asistencia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` int(11) NOT NULL,
  `ponencia` int(6) NOT NULL,
  `prioridad` int(5) NOT NULL DEFAULT '0',
  `fecha_insercion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`,`ponencia`,`usuario`),
  KEY `fk_asistencia_auditorio1_idx` (`usuario`),
  KEY `fk_asistencia_ponentes_idx` (`ponencia`),
  CONSTRAINT `fk_asistencia_auditorio1` FOREIGN KEY (`usuario`) REFERENCES `auditorio` (`id_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_asistencia_ponentes` FOREIGN KEY (`ponencia`) REFERENCES `ponentes` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `asistencia` (`id`, `usuario`, `ponencia`, `prioridad`, `fecha_insercion`) VALUES
(161,	1,	12,	10,	'2013-04-22 16:53:02'),
(162,	2,	12,	10,	'2013-04-22 16:53:14'),
(163,	3,	12,	10,	'2013-04-22 17:00:14'),
(164,	4,	12,	10,	'2013-04-22 17:01:14'),
(165,	5,	12,	10,	'2013-04-22 17:04:00'),
(175,	6,	12,	9,	'2013-04-23 04:43:10'),
(176,	6,	13,	3,	'2013-04-23 04:43:10'),
(180,	7,	12,	10,	'2013-04-24 14:00:55'),
(181,	7,	13,	10,	'2013-04-24 14:00:55');

DROP TABLE IF EXISTS `auditorio`;
CREATE TABLE `auditorio` (
  `id_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) CHARACTER SET utf8 NOT NULL,
  `apellidos` varchar(200) CHARACTER SET utf8 NOT NULL,
  `email` varchar(255) CHARACTER SET utf8 NOT NULL,
  `plan` char(1) CHARACTER SET utf8 NOT NULL,
  `avance` int(1) NOT NULL,
  `boleta` int(5) DEFAULT NULL COMMENT '	',
  `ife` varchar(40) CHARACTER SET utf8 NOT NULL COMMENT 'clave de elector',
  `tipo_usuario` int(2) NOT NULL COMMENT '30 .- alumno\n20 .- egresado\n10 .- invitado\n\nDonde el alumno es la maxima prioridad\nEste campo se llena desde un trigger\n',
  `pass` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`id_usuario`,`ife`),
  UNIQUE KEY `ife_UNIQUE` (`ife`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `auditorio` (`id_usuario`, `nombre`, `apellidos`, `email`, `plan`, `avance`, `boleta`, `ife`, `tipo_usuario`, `pass`) VALUES
(1,	'Antonio ',	'UTF-8',	' antonio.gonzalez.mx@gmail.com',	'e',	0,	0,	'SDAD123',	20,	'tAAmm7SOew'),
(2,	'AntonioÃ© ',	'UTF-8',	' antonio.gonzalez.mx@gmail.com',	'e',	0,	0,	'SDAD123123',	20,	'cNBq11v8iM'),
(3,	'Pedro',	'UTF-8',	' antonio.gonzalez.mx@gmail.com',	'e',	0,	0,	'QWE23432QW',	20,	'lTtXjfL833'),
(4,	'asaéeé',	'UTF-8',	' antonio.gonzalez.mx@gmail.com',	'e',	0,	0,	'QWE23432QW1',	20,	'6JC4FW3Wxa'),
(5,	'Antonio de jesús',	'González Preciado',	' antonio.gonzalez.mx@gmail.com',	'e',	0,	0,	'QWE23432QW12',	20,	'S3bM3B1gWj'),
(6,	'Juan',	'Alvarez',	' antonio.gonzalez.mx@gmail.com',	'n',	5,	2003640154,	'DAEQW23423',	30,	'zAnO17aKpN'),
(7,	'Juan',	'Mendoza',	'antonio.gonzalez.mx@gmail.com',	'i',	0,	0,	'GOMA2323',	10,	'hwjtIenhIj');

DROP TABLE IF EXISTS `ponentes`;
CREATE TABLE `ponentes` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `hora` char(11) DEFAULT NULL,
  `nombre` varchar(250) DEFAULT NULL,
  `empresa` varchar(250) DEFAULT NULL,
  `email` varchar(250) NOT NULL DEFAULT '',
  `pass` varchar(30) DEFAULT NULL,
  `ponencia` varchar(250) DEFAULT NULL,
  `clave` varchar(250) DEFAULT NULL,
  `perfil` varchar(100) DEFAULT NULL,
  `resumen` longtext,
  `taller` int(1) NOT NULL DEFAULT '0',
  `adm_hora_inicio` date DEFAULT NULL,
  `adm_hora_fin` date DEFAULT NULL,
  `adm_cupo` int(5) DEFAULT NULL,
  `adm_lugar` varchar(200) DEFAULT NULL,
  `adm_activa` int(5) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`,`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `ponentes` (`id`, `hora`, `nombre`, `empresa`, `email`, `pass`, `ponencia`, `clave`, `perfil`, `resumen`, `taller`, `adm_hora_inicio`, `adm_hora_fin`, `adm_cupo`, `adm_lugar`, `adm_activa`) VALUES
(12,	NULL,	'Antonio Gonzalez',	'Sintegra',	'antonio.gonzalez.mx@gmail.com',	'12345',	'Camel ESB',	'CVE',	'Todos',	'',	1,	NULL,	NULL,	NULL,	NULL,	1),
(13,	NULL,	'Juan Martinez',	'Helvex',	'juan.osorio@dor.com',	'',	'Tendencias del empleo',	'CVE1',	'Todos',	'',	0,	'0000-00-00',	'0000-00-00',	0,	'',	1);

-- 2013-04-24 22:41:52
