 <!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>MySql y PHP</title>
</head>
<body>
<?php
$server="localhost";
$user="witcom";
$password="labmovil";
$database="registro_taller";
$success = "Courses.html";
$error = "inscription.html";
$cn=mysql_connect($server, $user, $password) or die("Error al concetar al servidor mysql:".mysql_error());
$db=mysql_select_db($database,$cn) or die("Error al conectar a la base de datos:".mysql_error());
if($db)
echo "Conexión satisfactoria";
else
echo "No conecto a la Base de Datos";



$q1="select count(taller) from registro where taller="Taller_1";";
$q2="select count(taller) from registro where taller="Taller_2";";
$q3="select count(taller) from registro where taller="Taller_3";";
$q4="select count(taller) from registro where taller="Taller_4";";
$q5="select count(taller) from registro where taller="Taller_5";";
$q6="select count(taller) from registro where taller="Taller_6";";


if(mysql_query($queryStr)){
	header("Location: $success");
}
else{
	header("Location: $error");
}

mysql_close($conect);


?>


</body>

</html>
