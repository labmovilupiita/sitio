<?php
	class config{
		public static function getBBDDServer() {
			return 'localhost';
		}

		public static function getBBDDName(){
			return  'registro_witcom'; 
		}

		public static function getBBDDUser(){
			return 'root'; 
		} 

		public static function getBBDDPwd(){
			return 'labmovil'; 
		}
	}
?>
