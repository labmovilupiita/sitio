 <!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>MySql y PHP</title>
</head>
<body>
<?php
$server="localhost";
$user="witcom";
$password="labmovil";
$database="registro_taller";
$success = "Courses.html";
$error = "inscription.html";
$cn=mysql_connect($server, $user, $password) or die("Error al concetar al servidor mysql:".mysql_error());
$db=mysql_select_db($database,$cn) or die("Error al conectar a la base de datos:".mysql_error());
if($db)
echo "Conexión satisfactoria";
else
echo "No conecto a la Base de Datos";


$apellido = $_POST['apellido'];
$nombre = $_POST['nombre'];
$genero = $_POST['genero'];
$procedencia = $_POST['procedencia'];
$taller = $_POST['taller'];
$baucher = $_POST['baucher'];
echo "$apellido";
echo "$nombre";
echo "$genero";
echo "$procedencia";
echo "$taller";
$queryStr="INSERT INTO registro (`nombre`,`apellido`,`genero`,`procedencia`,`taller`) VALUES ('$nombre','$apellido','$genero','$procedencia','$taller')";
if(mysql_query($queryStr)){
	header("Location: $success");
}
else{
	header("Location: $error");
}

mysql_close($conect);


?>


</body>

</html>
